﻿namespace SoftUni
{
    public class Configuration
    {
        public const string ConfigurationString = "Server=DESKTOP-CP2NEHV\\SQLEXPRESS;Database=SoftUni;Integrated Security=True;";
    }
}