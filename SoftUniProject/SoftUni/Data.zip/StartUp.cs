﻿using SoftUni.Data;
using System;
using System.Linq;


namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            
         
        }
    }
}
