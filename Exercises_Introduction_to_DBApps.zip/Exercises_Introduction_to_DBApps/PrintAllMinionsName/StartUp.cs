﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using _2_Villain_Names;

namespace PrintAllMinionsName
{
    class StartUp
    {
        private const string selectMinionsName = (@"..\AllMinionsName.txt");

        static void Main(string[] args)
        {

            IList<string> listOfNames = new List<string>();
            using (SqlConnection connection = new SqlConnection(Configure.connectionString))
            {
                connection.Open();

                var names = File.ReadAllText(selectMinionsName);

                using (SqlCommand command = new SqlCommand(names, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            listOfNames.Add(reader.GetString(0));
                        }

                        for (int first = 0, last = listOfNames.Count-1;   first <= last; first++, last--)
                        {
                            Console.WriteLine(listOfNames[first]);
                            if (first != last)
                            {
                                Console.WriteLine(listOfNames[last]);
                            }
                        }
                    }
                }
            }

        }
    }
}
