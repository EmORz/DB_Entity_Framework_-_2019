﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using _2_Villain_Names;

namespace _8_IncreaseMinionAge
{
    class StartUp
    {
        private const string selectMinionsName = (@"..\IncreaseMinions.txt");

        static void Main(string[] args)
        {
            var minionsId = Console.ReadLine().Split(new char[] {' ', '\n', '\r', '\t'}, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();

            using (SqlConnection connection = new SqlConnection(Configure.connectionString))
            {
                connection.Open();
                var cmdText = File.ReadAllText(selectMinionsName)
                    .Replace("@idCollection", string.Join(", ", minionsId));

                using (SqlCommand command = new SqlCommand(cmdText, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine(reader.Read());
                            Console.WriteLine(command.ExecuteNonQuery());

                        }
                    }
                }


            }
        }
    }
}
