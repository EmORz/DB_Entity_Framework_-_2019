﻿namespace _4_Add_Minion.Models
{
    public class Minions
    {
        public Minions(string name, int age, string towns)
        {
           this.Name = name;
           this.Age = age;
           this.Towns = towns;
        }

        public string Name { get; set; }

        public int Age { get; set; }

        public string Towns { get; set; }

    }
}