﻿namespace _4_Add_Minion.Models
{
    public class Villains
    {
        public Villains(string name, string evelnesFactor)
        {
            this.Name = name;
            this.EvelnesFactor = evelnesFactor;
        }

        public string Name { get; set; }

        public string EvelnesFactor { get; set; }
    }
}