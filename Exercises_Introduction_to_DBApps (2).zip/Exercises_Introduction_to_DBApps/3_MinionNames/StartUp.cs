﻿using System;
using System.Data.SqlClient;
using System.IO;
using _2_Villain_Names;

namespace _3_MinionNames
{
    public class StartUp
    {
        private const string text = (@"..\SelectMinionsVillains.txt");


        public static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());

            using (SqlConnection connection = new SqlConnection(Configure.connectionString))
            {
                connection.Open();
                string cmdText = string.Format(File.ReadAllText(text), num);

                using (SqlCommand command = new SqlCommand(cmdText, connection))
                {
                    command.Parameters.AddWithValue("@vilainId", num);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();
                            Console.WriteLine($"Villain: {reader[0]}");

                            if (reader.IsDBNull(1))
                            {
                                Console.WriteLine("(no minions)");
                            }
                            else
                            {
                                var minionNum = 1;
                                while (true)
                                {
                                    Console.WriteLine($"{minionNum++}. {reader[1]} {reader[2]}");
                                    if (!reader.Read())
                                    {
                                        break;
                                    }
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine($"No villain with ID {num} exists in the database.");
                        }
                    }
                }


            }
        }
    }
}
