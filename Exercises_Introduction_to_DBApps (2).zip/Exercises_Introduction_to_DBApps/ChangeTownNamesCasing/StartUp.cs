﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using _2_Villain_Names;

namespace ChangeTownNamesCasing
{
    class StartUp
    {
        private const string selectTownName = (@"..\SelectNameTown.txt");
        private const string updtaeTownName = (@"..\UpdateName.txt");


        static void Main(string[] args)
        {
            var countryName = Console.ReadLine();

            using (SqlConnection connection = new SqlConnection(Configure.connectionString))
            {
                connection.Open();

                var cmdText = File.ReadAllText(updtaeTownName);

                using (SqlCommand command = new SqlCommand(cmdText, connection))
                {
                    command.Parameters.AddWithValue("@countryName", countryName);
                    var numOfAffectedTowns = (int)command.ExecuteNonQuery();
                    if (numOfAffectedTowns == 0)
                    {
                        Console.WriteLine("No town names were affected.");
                        return;
                    }
                    else
                    {
                        Console.WriteLine($"{numOfAffectedTowns} town names were affected.");
                    }
                    var cmdTextF = File.ReadAllText(selectTownName);

                    using (SqlCommand commandF = new SqlCommand(cmdTextF, connection))
                    {
                        commandF.Parameters.AddWithValue("@countryName", countryName);

                        using (SqlDataReader reader = commandF.ExecuteReader())
                        {
                            IList<string> temp = new List<string>();
                            var count = 1;
                            while (reader.Read())
                            {
                                temp.Add(count+"."+reader.GetString(0));
                                count++;
                            }
                            Console.WriteLine(string.Join(", ", temp));
                        }
                    }

                }

            }


        }
    }
}
