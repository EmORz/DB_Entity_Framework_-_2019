﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Transactions;
using _2_Villain_Names;
using _4_Add_Minion.Models;

namespace _4_Add_Minion
{
    class StartUp
    {

        private const string TownInsertionQueryPath = @"C:\Users\User\source\repos\Exercises_Introduction_to_DBApps\4_Add_Minion\SQL\TownInsert.txt";
        private const string CountryInsertionQueryPath = @"..\..\SQL Queries\CountryInsertation.sql";
        private const string MinionInsertionQueryPath = @"C:\Users\User\source\repos\Exercises_Introduction_to_DBApps\4_Add_Minion\SQL\MinionsInsert.txt";
        private const string VillainInsertionQueryPath = @"C:\Users\User\source\repos\Exercises_Introduction_to_DBApps\4_Add_Minion\SQL\VillainInsert.txt";
        private const string MinionVillainInsertionQueryPath = @"C:\Users\User\source\repos\Exercises_Introduction_to_DBApps\4_Add_Minion\SQL\MinionsVilainInsert.txt";
        private const string DefaultCoutryName = "Undefined";

        static void Main(string[] args)
        {
            //has bug! dont work 
            while (true)
            {
                Minions minion = GetMinionFromConsole();
                Villains villain = GeVillainFromConsole();

                using (TransactionScope transactionScope = new TransactionScope())
                {
                    using (SqlConnection connection = new SqlConnection(Configure.connectionString))
                    {
                        connection.Open();
                        //
                        AssureTownExists(minion.Towns, connection);
                        AssureMinionExists(minion, connection);
                        AssureVillainExists(villain, connection);
                        AddMinionToVillainServants(minion.Name, villain.Name, connection);
                    }

                    transactionScope.Complete();
                }
            }
        }

        private static void AddMinionToVillainServants(string minionName, string villainName, SqlConnection connection)
        {
            string cmdText = File.ReadAllText(MinionVillainInsertionQueryPath);
            using (SqlCommand command = new SqlCommand(cmdText, connection))
            {
                command.Parameters.AddWithValue("@minionName", minionName);
                command.Parameters.AddWithValue("@villainName", villainName);
                command.ExecuteNonQuery();
            }
            Console.WriteLine($"Successfully added {minionName} to be minion of {villainName}");
        }

        private static void AssureVillainExists(Villains villain, SqlConnection connection)
        {
            if (IsRecordAvailable(villain.Name, "Name", "Villains", connection))
            {
                return;
            }

            string cmdText = File.ReadAllText(VillainInsertionQueryPath);
            using (SqlCommand command = new SqlCommand(cmdText, connection))
            {
                command.Parameters.AddWithValue("@name", villain.Name);
                command.Parameters.AddWithValue("@evilnessFactor", villain.EvelnesFactor);
                command.ExecuteNonQuery();
            }

            Console.WriteLine($"Villain {villain.Name} was added to the database.");
        }

        private static void AssureMinionExists(Minions minion, SqlConnection connection)
        {

            if (IsRecordAvailable(minion.Name, "Name", "Minions", connection))
            {
                return;
            }

            string cmdText = File.ReadAllText(MinionInsertionQueryPath);
            SqlCommand command = new SqlCommand(cmdText, connection);
            command.Parameters.AddWithValue("@townName", minion.Towns);
            command.Parameters.AddWithValue("@name", minion.Name);
            command.Parameters.AddWithValue("@age", minion.Age);
            command.ExecuteNonQuery();

            Console.WriteLine($"Minion {minion.Name} was added to the database.");
        }

        private static void AssureTownExists(string minionTowns, SqlConnection connection)
        {
            if (IsRecordAvailable(minionTowns, "Name", "Towns", connection))
            {
                return;
            }

            AssureCountryIsAvailable(DefaultCoutryName, connection);

            string cmdText = File.ReadAllText(TownInsertionQueryPath);
            using (SqlCommand command = new SqlCommand(cmdText, connection))
            {
                command.Parameters.AddWithValue("@countryName", DefaultCoutryName);
                command.Parameters.AddWithValue("@townName", minionTowns);
                command.ExecuteNonQuery();
            }

            Console.WriteLine($"Town {minionTowns} was added to the database.");
        }

        private static void AssureCountryIsAvailable(string coutryName, SqlConnection connection)
        {
            if (IsRecordAvailable(DefaultCoutryName, "Name", "Countries", connection))
            {
                return;
            }

            string cmdText = File.ReadAllText(CountryInsertionQueryPath);
            using (SqlCommand command = new SqlCommand(cmdText, connection))
            {
                command.Parameters.AddWithValue("@countryName", coutryName);
                command.ExecuteNonQuery();
            }
        }
        private static bool IsRecordAvailable(string keyValue, string colName, string tableName, SqlConnection connection)
        {
            object selection = null;
            string cmdText = $"SELECT {colName} FROM {tableName} WHERE {colName} = '{keyValue}';";
            using (SqlCommand command = new SqlCommand(cmdText, connection))
            {
                command.Parameters.AddWithValue("@keyValue", keyValue);
                selection = command.ExecuteScalar();
            }

            return selection != DBNull.Value && selection != null;
        }

        private static Villains GeVillainFromConsole()
        {
            string[] villainData = Console.ReadLine()
                .Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                .Skip(1)
                .ToArray();

            string name = villainData[0];
            if (villainData.Length == 1)
            {
                return new Villains(name);
            }

            string evilnessFactor = villainData[0];
            return new Villains(name, evilnessFactor);
        }

        private static Minions GetMinionFromConsole()
        {
            string[] minionData = Console.ReadLine()
                .Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                .Skip(1)
                .ToArray();

            string name = minionData[0];
            int age = int.Parse(minionData[1]);
            string town = minionData[2];

            return new Minions(name, age, town);
        }
    }
}
