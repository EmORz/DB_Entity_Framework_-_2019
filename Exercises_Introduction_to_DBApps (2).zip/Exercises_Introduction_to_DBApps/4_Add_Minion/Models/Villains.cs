﻿namespace _4_Add_Minion.Models
{
    public class Villains
    {
        private const string DefaultEvilnessFactor = "Evil";

        public Villains(string name):this(name, DefaultEvilnessFactor)
        {
        }
        public Villains(string name, string evelnesFactor)
        {
            this.Name = name;
            this.EvelnesFactor = evelnesFactor;
        }

        public string Name { get; set; }

        public string EvelnesFactor { get; set; }
    }
}