﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Transactions;
using _2_Villain_Names;

namespace _6_RemoveVillain
{
    public class StartUp
    {
        private const string MinionsVillainsDeletionQueryPath = @"C:\Users\User\source\repos\Exercises_Introduction_to_DBApps\6_RemoveVillain\SqlQuery\DeleteMappTable.txt";
        private const string VillainNameSelectionQueryPath = @"C:\Users\User\source\repos\Exercises_Introduction_to_DBApps\6_RemoveVillain\SqlQuery\SelectVillainsById.txt";
        private const string VillainDeleteByIdQueryPath = @"C:\Users\User\source\repos\Exercises_Introduction_to_DBApps\6_RemoveVillain\SqlQuery\DeleteVillains.txt";
       

        public static void Main(string[] args)
        {
            var villainId = int.Parse(Console.ReadLine());
            var villainName = String.Empty;
            int numOfRealaseMinions = 0;


            using (TransactionScope transaction = new TransactionScope())
            {
                using (SqlConnection connection = new SqlConnection(Configure.connectionString))
                {
                    connection.Open();

                    var selectVillainByName = File.ReadAllText(VillainNameSelectionQueryPath);
                    using (SqlCommand command = new SqlCommand(selectVillainByName, connection))
                    {
                        command.Parameters.AddWithValue("@villainId", villainId);
                        villainName = (string) command.ExecuteScalar();

                        if (string.IsNullOrEmpty(villainName))
                        {
                            Console.WriteLine("No such villain was found!");
                            return;
                            
                        }
                    }

                    var dellMapping = File.ReadAllText(MinionsVillainsDeletionQueryPath);
                    using (SqlCommand command = new SqlCommand(dellMapping, connection))
                    {
                        command.Parameters.AddWithValue("@villainId", villainId);
                        numOfRealaseMinions = (int)command.ExecuteNonQuery();
                    }
                    var dellVillain = File.ReadAllText(VillainDeleteByIdQueryPath);
                    using (SqlCommand command = new SqlCommand(dellVillain, connection))
                    {
                        command.Parameters.AddWithValue("@villainId", villainId);
                        command.ExecuteNonQuery();
                    }
                }
                transaction.Complete();
            }

            Console.WriteLine($"{villainName} was deleted.");
            Console.WriteLine($"{numOfRealaseMinions} minions were released.");
        }
    }
}

 
