﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using _2_Villain_Names;

namespace _9_Increase_Age_Stored_Procedure
{
    class StartUp
    {
        private const string connectionString = @"Server=DESKTOP-CP2NEHV\SQLEXPRESS;Database=MinionsDB;Integrated Security=true;";
        private const string storeProcedure = (@"..\StoreProcedure.txt");
        private const string selectMinions = (@"..\SelectMinions.txt");

        static void Main(string[] args)
        {
            //Just to create store procedure

            //using (SqlConnection connection = new SqlConnection(Configure.connectionString))
            //{
            //    connection.Open();
            //    var storeP = File.ReadAllText(storeProcedure);

            //    using (SqlCommand command = new SqlCommand(storeP, connection))
            //    {
            //        command.ExecuteNonQuery();

            //    }
            //}
            var minionId = int.Parse(Console.ReadLine());

            using (SqlConnection connection = new SqlConnection(Configure.connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("usp_GetOlder", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@minionId", minionId);
                    command.ExecuteNonQuery();
                }

                var cmdText = File.ReadAllText(selectMinions);

                using (SqlCommand command = new SqlCommand(cmdText, connection))
                {
                    command.Parameters.AddWithValue("@minionId", minionId);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        var temp = "";
                        if (reader.Read())
                        {
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                if (i == 0)
                                {
                                    temp += reader[i].ToString()+" - ";
                                }
                                else
                                {
                                    temp += reader[i];
                                }
                            }
                            Console.WriteLine(temp+" years old");
                        }
                    }
                }
            }
        }
    }
}
