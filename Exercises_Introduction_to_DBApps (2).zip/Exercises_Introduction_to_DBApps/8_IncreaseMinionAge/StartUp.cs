﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using _2_Villain_Names;

namespace _8_IncreaseMinionAge
{
    class StartUp
    {
        private const string selectMinionsName = (@"C:\Users\User\source\repos\Exercises_Introduction_to_DBApps\8_IncreaseMinionAge\bin\Debug\IncreaseMinions.txt");

        static void Main(string[] args)
        {
            IEnumerable<int> minionsId = Console.ReadLine().Split(new char[] {' ', '\n', '\r', '\t'}, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();

            using (SqlConnection connection = new SqlConnection(Configure.connectionString))
            {
                connection.Open();
                var cmdText = File.ReadAllText(selectMinionsName)
                    .Replace("@idCollection", string.Join(", ", minionsId));

                using (SqlCommand command = new SqlCommand(cmdText, connection))
                {
                    int temp = (int) command.ExecuteNonQuery();
                    Console.WriteLine(temp);
                }


            }
        }
    }
}
