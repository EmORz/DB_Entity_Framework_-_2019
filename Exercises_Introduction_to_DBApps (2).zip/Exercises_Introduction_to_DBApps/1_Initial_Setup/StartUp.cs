﻿using System.Data.SqlClient;
using System.IO;
using _2_Villain_Names;

namespace _1_Initial_Setup
{
    public class StartUp
    {
        private const string DbName = "MinionsDB";
        private const string ServerName = @"DESKTOP-CP2NEHV\SQLEXPRESS";
        private const string Authentication = "Integrated Security=true";
        //
        public static void Main(string[] args)
        {
            CreateDatabase(DbName, ServerName, Authentication);

            using (SqlConnection connection = new SqlConnection(Configure.connectionString))
            {
                connection.Open();
                string text = File.ReadAllText(@"..\TablesData.txt");
                using (SqlCommand command = new SqlCommand(text, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }
        private static void CreateDatabase(string dbName, string serverName, string authentication)
        {

            string connectionString = $@"
                Server={serverName}; 
                Database=master; 
                {authentication};";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand($"CREATE DATABASE {dbName};", connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
