﻿namespace _2_Villain_Names
{
    public static class Configure
    {
        public const string connectionString = @"Server=DESKTOP-CP2NEHV\SQLEXPRESS;Database=MinionsDB;Integrated Security=true;";
    }
}