﻿using System;
using System.Data.SqlClient;
using System.IO;

namespace _2_Villain_Names
{
    public class StartUp
    {

        public static void Main(string[] args)
        {
            using (SqlConnection connection = new SqlConnection(Configure.connectionString))
            {
                connection.Open();
                string text = File.ReadAllText(@"..\VillainMinions.txt");
                using (SqlCommand command = new SqlCommand(text, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                Console.Write($"{reader.GetName(i),-10}");
                            }

                            Console.WriteLine();

                            while (reader.Read())
                            {
                                for (int i = 0; i < reader.FieldCount; i++)
                                {
                                    Console.Write($"{reader[i], -10}");
                                }

                                Console.WriteLine();
                            }
                        }
                    }
                }

            }

        }
    }
}
